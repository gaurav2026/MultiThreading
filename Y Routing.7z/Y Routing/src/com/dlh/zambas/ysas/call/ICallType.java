package com.dlh.zambas.ysas.call;

import java.util.concurrent.Callable;

/**
 * 
 * @author singhg
 *
 */
public interface ICallType extends Callable<String>{
	@Override
	public String call() throws Exception;
}
