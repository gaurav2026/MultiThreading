package com.dlh.zambas.ysas.backend.payload;

import java.io.StringWriter;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.actional.soapstation.plugin.inproc.DOMType;
import com.actional.soapstation.plugin.inproc.ICallInfo;
import com.dlh.zambas.ysas.utils.LoggerUtil;
import com.dlh.zambas.ysas.utils.YSasConstants;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * check whether request is SOAP or REST and then replace the dummy value of
 * RequestID with actual one
 * 
 * @author singhg
 *
 */
public class ModifyPayloadImpl implements IModifyPayload {

	/**
	 * call REST or SOAP method based on what type of call is made
	 */
	@Override
	public String modifyPayload(ICallInfo callInfo, String requestID)
			throws Exception {
		if (null != callInfo.getMessageContent()
				&& callInfo.getMessageContent().length > 0) {
			if (callInfo.getAccessPointName().contains(
					YSasConstants.AccessPoint.toString())) {
				return modifyRESTPayload(callInfo, requestID);
			} else {
				return modifySOAPPayload(callInfo, requestID);
			}
		} else {
			return null;
		}
	}

	/**
	 * replace dummy 'RequestID' value with actual one
	 * @param callInfo
	 * @param requestID
	 * @return
	 * @throws Exception
	 */
	private String modifyRESTPayload(ICallInfo callInfo, String requestID)
			throws Exception {
		try {
			JsonElement jsonElement = new JsonParser().parse(new String(
					callInfo.getMessageContent()));
			JsonObject jsonObject = (JsonObject) jsonElement.getAsJsonObject()
					.get(YSasConstants.inputs.toString());
			jsonObject.addProperty(YSasConstants.RequestID.toString(),
					requestID);
			return new Gson().toJson(jsonElement);
		} catch (Exception e) {
			LoggerUtil.logErrorMessages(
					"Exception occured in parsing SOAP request : ", e);
			throw new Exception("Exception occured in parsing SOAP request : ",
					e);
		}
	}

	/**
	 * replace dummy 'RequestID' value with actual one
	 * @param callInfo
	 * @param requestID
	 * @return
	 * @throws Exception
	 */
	private String modifySOAPPayload(ICallInfo callInfo, String requestID)
			throws Exception {
		try {
			Document doc = callInfo.getXmlDocument(
					DOMType.XML_DOCUMENT_READ_ONLY).getDOM(true);

			if (doc.hasChildNodes()) {
				return modifySOAPPayload(doc, doc.getChildNodes(), requestID);
			}
			return null;
		} catch (Exception e) {
			LoggerUtil.logErrorMessages(
					"Exception occured in parsing SOAP request : ", e);
			throw new Exception("Exception occured in parsing SOAP request : ",
					e);
		}
	}

	/**
	 * iterate till RequestID tag and replace dummy 'RequestID' value with actual one
	 * @param doc
	 * @param nodeList
	 * @param requestID
	 * @return
	 * @throws Exception
	 */
	private String modifySOAPPayload(Document doc, NodeList nodeList,
			String requestID) throws Exception {
		boolean status = false;
		NodeList childList = null;
		for (int nodeCount = 0; nodeCount < nodeList.getLength(); nodeCount++) {
			Node documentNode = nodeList.item(nodeCount);
			// make sure it's element node.
			if (documentNode.getNodeType() == Node.ELEMENT_NODE) {
				Element requestElement = (Element) documentNode;
				if (requestElement.getAttribute(YSasConstants.name.toString())
						.equalsIgnoreCase(YSasConstants.RequestID.toString())) {
					String tagName = null;
					if (null != requestElement.getTagName()
							&& !requestElement.getTagName().isEmpty()) {
						tagName = requestElement.getTagName().substring(0,
								requestElement.getTagName().indexOf(":") + 1);
					}
					if (null != tagName) {
						childList = requestElement.getElementsByTagName(tagName
								+ YSasConstants.Val.toString());
					} else {
						childList = requestElement
								.getElementsByTagName(YSasConstants.Val
										.toString());
					}
					for (int requestIDNodeCount = 0; requestIDNodeCount < childList
							.getLength(); requestIDNodeCount++) {
						Node requestNode = childList.item(requestIDNodeCount);
						requestNode.setTextContent(requestID);
						status = true;
						break;

					}
					if (status) {
						break;
					}
				}

				if (documentNode.hasChildNodes()) {
					// loop again if has child nodes
					modifySOAPPayload(doc, documentNode.getChildNodes(),
							requestID);

				}

			}
			if (status) {
				break;
			}

		}
		Transformer tf = TransformerFactory.newInstance().newTransformer();
		tf.setOutputProperty(OutputKeys.INDENT, YSasConstants.yes.toString());
		tf.setOutputProperty(OutputKeys.METHOD, YSasConstants.xml.toString());

		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult sr = new StreamResult(writer);
		tf.transform(domSource, sr);
		return writer.toString();

	}

}
