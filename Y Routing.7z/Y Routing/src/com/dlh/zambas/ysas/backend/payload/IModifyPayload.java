package com.dlh.zambas.ysas.backend.payload;

import com.actional.soapstation.plugin.inproc.ICallInfo;

public interface IModifyPayload {
	
	String modifyPayload(ICallInfo callInfo, String requestID) throws Exception;
}
