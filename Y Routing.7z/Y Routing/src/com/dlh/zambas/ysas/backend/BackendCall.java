package com.dlh.zambas.ysas.backend;

import java.util.concurrent.Callable;

import com.actional.soapstation.plugin.inproc.ICallInfo;
import com.dlh.zambas.ysas.utils.YSasConstants;

/**
 * add requestId in header and payload and then route the call to backend
 * 
 * @author singhg
 *
 */
public class BackendCall implements Callable<String>{

	private String requestId = null;
	private ICallInfo callInfo = null;
	private String payload = null;

	/**
	 * 
	 * @param requestId
	 * @param callInfo
	 */
	public BackendCall(String requestId, String payload, ICallInfo callInfo) {
		this.requestId = requestId;
		this.payload = payload;
		this.callInfo = callInfo;
	}

	@Override
	public String call() throws Exception {
		return callBackend();

	}

	/**
	 * add requestId in header and payload and then route the call to backend
	 * 
	 * @return
	 * @throws Exception
	 */
	private String callBackend() throws Exception {
		callInfo.getTransportProperties().put(
				YSasConstants.RequestID.toString(), requestId);
		callInfo.setTransportProperties(callInfo.getTransportProperties(), true);
		callInfo.setMessageContent(payload.getBytes(), true);
		return "backend called successfully";
	}

}
