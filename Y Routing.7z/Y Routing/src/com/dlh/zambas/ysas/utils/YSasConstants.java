package com.dlh.zambas.ysas.utils;

public enum YSasConstants {
	Host,
	customer,
	queueName,
	SETTINGS,
	Message,
	Type,
	ServiceName,
	Operation,
	AccessPoint,
	REST,
	SOAP,
	RestHeaders,
	PathParam,
	QueryParam,
	PayLoad,
	CustomerID,
	ApplicationID,
	Val,
	name,
	inputs,
	headers_namespace("http://com.dlh.zambas.japi"),
	mashery_customer_header("x-dlh-customer-id"),
	mashery_application_id("x-dlh-application-id"),
	xml,
	UTF("UTF-8"),
	yes,
	RequestID;
	
	private String value = null;

	YSasConstants(String value) {
		this.value = value;
	}

	private YSasConstants() {
	}

	public String value() {
		return value;
	}
	
}
