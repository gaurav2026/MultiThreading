package com.dlh.zambas.ysas.utils;

import com.actional.catalog.Catalog;

/** 
 * 
 * Needed for implementing AI logger APIs
 *
 */
public class PrepareFaultCatalog extends Catalog {

	private static final long serialVersionUID = 1L;

	public PrepareFaultCatalog(String name, String id, Class<?> baseNameClass) {
		super(name, id, baseNameClass);
	}
}
