package com.dlh.zambas.ysas.utils;

import com.actional.catalog.Catalog;
import com.actional.catalog.Message;
import com.actional.log.ILogger;
import com.actional.log.LoggerFactory;

/**
 * Logger class to log info or error messages
 * @author singhg
 *
 */
public class LoggerUtil {

	private static Message INFO_MSG = null;
	private static Message ERROR_MSG = null;
	private static Catalog CATALOG = new PrepareFaultCatalog(
			"RequestId insertion for Y_SAS services", "EXTRACT-MESSAGE-PLUGIN",
			LoggerUtil.class);
	private static ILogger logger = LoggerFactory.get();

	public static void logInfoMessages(String message) {
		INFO_MSG = new Message(CATALOG, message, 1);
		logger.log(INFO_MSG);
	}

	public static void logErrorMessages(String message, Exception e) {
		ERROR_MSG = new Message(CATALOG, message, 3);
		logger.log(ERROR_MSG, e);
	}

}
