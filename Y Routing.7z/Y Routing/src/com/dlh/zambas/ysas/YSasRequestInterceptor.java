package com.dlh.zambas.ysas;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

import com.actional.soapstation.plugin.inproc.ICallInfo;
import com.actional.soapstation.plugin.inproc.IInit;
import com.actional.soapstation.plugin.inproc.IInterceptor;
import com.actional.soapstation.plugin.inproc.MessageType;
import com.dlh.zambas.ysas.backend.BackendCall;
import com.dlh.zambas.ysas.backend.payload.IModifyPayload;
import com.dlh.zambas.ysas.backend.payload.ModifyPayloadImpl;
import com.dlh.zambas.ysas.call.ICallType;
import com.dlh.zambas.ysas.queue.QueueCall;
import com.dlh.zambas.ysas.utils.LoggerUtil;
import com.dlh.zambas.ysas.utils.YSasConstants;

/**
 * Request interceptor
 * 
 * @author singhg
 *
 */
public class YSasRequestInterceptor implements IInterceptor, IInit {

	private String machineName = null;
	private String requestID = null;
	private ICallType callType = null;
	private BackendCall backendCall = null;
	private QueueCall queueCall = null;
	private String queueName = null;
	private String weblogicQueueResourceUri = null;
	private IModifyPayload modifyPayload = null;
	private String payload = null;

	/**
	 * all call related info such as payload, headers etc come in this method
	 * open two threads - one for backend call; other would form an xml message
	 * and call weblogic to push message to queue
	 */

	@Override
	public void invoke(IInvokeContext context) throws Exception {
		ICallInfo callInfo = context.getCallInfo();

		if (callInfo.getMessageType() == MessageType.REQUEST) {
			// form requestID
			requestID = formRequestID(callInfo);
			modifyPayload = new ModifyPayloadImpl();
			//payload 
			payload = modifyPayload.modifyPayload(callInfo, requestID);

			/**
			 * open 2 threads one would add requestID in header and payload;another would
			 * put message in queue
			 */
			backendCall = new BackendCall(requestID, payload, callInfo);
			queueCall = new QueueCall(requestID, payload, queueName,
					weblogicQueueResourceUri, callInfo);
			FutureTask<String> queueFutureTask = new FutureTask<String>(
					queueCall);
			FutureTask<String> backendFutureTask = new FutureTask<String>(
					backendCall);

			ExecutorService executor = Executors.newFixedThreadPool(2);
			executor.execute(backendFutureTask);
			executor.execute(queueFutureTask);

			while (true) {
				try {
					if (queueFutureTask.isDone() && backendFutureTask.isDone()) {
						LoggerUtil.logInfoMessages("Backend and queue call complete");
						// shut down executor service
						executor.shutdown();
						return;
					}

					if (!backendFutureTask.isDone()) {
						// wait indefinitely for future task to complete
						LoggerUtil.logInfoMessages("Backend Call output="
								+ backendFutureTask.get());
					}

					if (!queueFutureTask.isDone()) {

						LoggerUtil
								.logInfoMessages("Waiting for Queue call to complete");
						// 70 seconds as timeout between AI to weblogic is set
						// to be 70 seconds
						String queueCall = queueFutureTask.get(70,
								TimeUnit.SECONDS);
						if (queueCall != null) {
							LoggerUtil.logInfoMessages("Queue call output = "
									+ queueCall);
						}
					}
				} catch (InterruptedException | ExecutionException e) {
					LoggerUtil.logErrorMessages(
							"Exception occured in execution of threads ", e);
				} catch (Exception e) {
					LoggerUtil
							.logErrorMessages(
									"Time out exception occured between AI and weblogic  ",
									e);
				}
			}

		}
	}

	/**
	 * form requestId based on machineName_servicegroupname_currentimestamp
	 * 
	 * @param callInfo
	 * @return
	 * @throws UnknownHostException
	 */

	private String formRequestID(ICallInfo callInfo)
			throws UnknownHostException {
		Date currentDateTime = new Date();
		SimpleDateFormat ft = new SimpleDateFormat("yyMMddhhmmssMs");
		String datetime = ft.format(currentDateTime);
		return machineName + "_" + callInfo.getSvcGroupName().toUpperCase()
				+ "_" + datetime;
	}

	/**
	 * fetch machine name at the time of plugin deployment
	 */
	@Override
	public void init(IInitContext paramIInitContext) throws Exception {
		String[] items = ((String) paramIInitContext.getSettings().getSetting(
				YSasConstants.SETTINGS.toString())).split(";");

		LoggerUtil.logInfoMessages("Total items : " + items.length);

		/**
		 * initial check to confirm whether plugin contains all required params.
		 * One time activity required at time of plugin deployment.
		 */
		if (items.length != 2) {

			throw new Exception(
					"Wrong number of items in SETTINGS. (need 2: qeueName,webLogicResourceURI): "
							+ (String) paramIInitContext.getSettings()
									.getSetting(
											YSasConstants.SETTINGS.toString()));

		} else {
			// queueName
			queueName = items[0].substring(items[0].indexOf('=') + 1);
			// webLogicResourceURI = weblogic URL where plugin needs to make a
			// call
			weblogicQueueResourceUri = items[1]
					.substring(items[1].indexOf('=') + 1);
			// fetch machine name
			InetAddress myHost = InetAddress.getLocalHost();
			machineName = myHost.getHostName().toUpperCase();
			LoggerUtil.logInfoMessages(machineName);

		}

	}

	@Override
	public void destroy(IDestroyContext paramIDestroyContext) throws Exception {
		// TODO Auto-generated method stub

	}

	
}
