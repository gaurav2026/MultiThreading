package com.dlh.zambas.ysas.queue.payload;

import com.actional.soapstation.plugin.inproc.ICallInfo;
import com.dlh.zambas.ysas.payload.pojo.PayLoadToXMLPojo;

public interface IFormPayload {

	PayLoadToXMLPojo formRESTPayloadForQueue(ICallInfo callInfo, String requestID, String payload)
			throws Exception;

	PayLoadToXMLPojo formSOAPPayloadForQueue(ICallInfo callInfo, String requestID, String payload)
			throws Exception;

	
}
