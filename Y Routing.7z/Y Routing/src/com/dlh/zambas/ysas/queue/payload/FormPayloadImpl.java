package com.dlh.zambas.ysas.queue.payload;

import com.actional.soapstation.plugin.inproc.ICallInfo;
import com.dlh.zambas.ysas.payload.pojo.PayLoadToXMLPojo;

/**
 * form REST or SOAP payload for queue a
 * @author singhg
 *
 */
public class FormPayloadImpl implements IFormPayload {

	/**
	 * form REST payload
	 */
	@Override
	public PayLoadToXMLPojo formRESTPayloadForQueue(ICallInfo callInfo, String requestID, String payload)
			throws Exception {
		FormRESTPayload formRESTPayload = new FormRESTPayload();
		return formRESTPayload.formRESTPayloadForQueue(callInfo, requestID,payload);
	}

	/**
	 * form SOAP payload
	 */
	@Override
	public PayLoadToXMLPojo formSOAPPayloadForQueue(ICallInfo callInfo, String requestID,String payload) throws Exception {
		FormSOAPPayload formSOAPPayload = new FormSOAPPayload();
		return formSOAPPayload.formSOAPPayloadForQueue(callInfo, requestID,payload);
	}


	
}
