package com.dlh.zambas.ysas.queue.payload;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import com.actional.soapstation.plugin.inproc.ICallInfo;
import com.dlh.zambas.ysas.payload.pojo.PayLoadToXMLPojo;
import com.dlh.zambas.ysas.utils.LoggerUtil;
import com.dlh.zambas.ysas.utils.YSasConstants;

/**
 * Form REST payload for queue call
 * @author singhg
 *
 */
public class FormRESTPayload {

	private int totalPathParams = 0;
	private Map<String, List<Object>> queryParams = null;
	private Map<String, List<Object>> pathParams = null;
	private Map<String, List<Object>> parameters = null;
	private PayLoadToXMLPojo payLoadToXMLPojo = null;

	/**
	 * set PayLoadToXMLPojo 
	 * @param callInfo
	 * @param requestID
	 * @param payload
	 * @return
	 * @throws Exception
	 */
	public PayLoadToXMLPojo formRESTPayloadForQueue(ICallInfo callInfo,
			String requestID, String payload) throws Exception {
		try{
		payLoadToXMLPojo = new PayLoadToXMLPojo();
		payLoadToXMLPojo.setRequestID(requestID);
		payLoadToXMLPojo.setType(YSasConstants.REST.toString());
		payLoadToXMLPojo.setServiceName(callInfo.getSvcGroupName());
		payLoadToXMLPojo.setOperationName(callInfo.getOperationName());
		Map<String, Object> headersMap = new TreeMap<String, Object>(
				String.CASE_INSENSITIVE_ORDER);
		headersMap = fetchParametersFromRequest(callInfo);

		payLoadToXMLPojo.setCustomerID((String) (headersMap
				.get(YSasConstants.CustomerID.toString()) != null ? headersMap
				.get(YSasConstants.CustomerID.toString()) : headersMap
				.get(YSasConstants.mashery_customer_header.value())));
		payLoadToXMLPojo
				.setApplicationID((String) (headersMap
						.get(YSasConstants.ApplicationID.toString()) != null ? headersMap
						.get(YSasConstants.ApplicationID.toString())
						: headersMap.get(YSasConstants.mashery_application_id
								.value())));

		payLoadToXMLPojo.setRestHeaders(headersMap.toString());
		/**
		 * set query and path params .AI doesn't provide direct access to these
		 * and, therefore , this work around
		 */
		fetchParametersFromRequest(callInfo);

		if (null != payload && !payload.isEmpty())
			payLoadToXMLPojo.setBody(payload);

		return payLoadToXMLPojo;
		}catch(Exception e){
			LoggerUtil.logErrorMessages("Exception occured while forming REST payload for queue", e);
			throw new Exception("Exception occured while forming REST payload for queue", e);
		}

	}

	/**
	 * fetch path and query params from operation parameters
	 * returns a map from which customerID and applicationID are fetched
	 * @param callInfo
	 * @throws Exception
	 */
	private Map<String, Object> fetchParametersFromRequest(ICallInfo callInfo)
			throws Exception {
		if (callInfo.getParameters().size() > 0) {
			/**
			 * avoid case sensitivity of headers
			 */
			Map<String, Object> map = new TreeMap<String, Object>(
					String.CASE_INSENSITIVE_ORDER);
			map.putAll(callInfo.getTransportProperties());
			int counter = 0;
			parameters = callInfo.getParameters();
			Map<String, List<Object>> sortedParams = new LinkedHashMap<String, List<Object>>(
					parameters);
			totalPathParams = countCompleteBrackets(callInfo.getOperationName());
			pathParams = new LinkedHashMap<String, List<Object>>();
			queryParams = new LinkedHashMap<String, List<Object>>();
			for (Map.Entry<String, List<Object>> entry : sortedParams
					.entrySet()) {
				String key = entry.getKey();
				List<Object> value = entry.getValue();
				for (Object val : entry.getValue()) {
					if (++counter <= totalPathParams) {
						pathParams.put(key, value);
					} else {
						queryParams.put(key, value);
					}
					map.put(key, val);
				}
				
			}

			payLoadToXMLPojo.setPathParams(pathParams);
			payLoadToXMLPojo.setQueryParams(queryParams);
			return map;
		}
		return null;
	}

	
	/**
	 * work around to fetch Path parameters complete braces determine number of
	 * path params
	 * 
	 * @param operationName
	 * @return
	 */
	private int countCompleteBrackets(String operationName) {
		int counter = 0;
		int countBrackets = 0;
		for (int pathParamCounter = 0; pathParamCounter < operationName
				.length(); pathParamCounter++) {
			if (operationName.charAt(pathParamCounter) == '{') {
				counter++;
			} else if (operationName.charAt(pathParamCounter) == '}') {
				if (counter == 0) {
					return 0;
				}
				countBrackets++;
				counter--;
			}
		}
		return countBrackets;
	}

}
