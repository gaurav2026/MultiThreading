package com.dlh.zambas.ysas.queue;

import java.util.concurrent.Callable;

import javax.ws.rs.core.MediaType;

import com.actional.soapstation.plugin.inproc.ICallInfo;
import com.dlh.zambas.ysas.payload.pojo.PayLoadToXMLPojo;
import com.dlh.zambas.ysas.payload.queue.structure.IPayLoadToXMLForQueue;
import com.dlh.zambas.ysas.payload.queue.structure.PayLoadToXMLForQueue;
import com.dlh.zambas.ysas.request.type.IRequestType;
import com.dlh.zambas.ysas.request.type.RequestTypeImpl;
import com.dlh.zambas.ysas.utils.LoggerUtil;
import com.dlh.zambas.ysas.utils.YSasConstants;
import com.google.gson.JsonObject;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

/**
 * call queueService to push requestId and request to queue
 * 
 * @author singhg
 *
 */
public class QueueCall implements Callable<String> {

	private String requestId = null;
	private String queueName = null;
	private String weblogicQueueResourceUri = null;
	private ClientResponse clientResponse = null;
	private Client client = null;
	private WebResource webResource = null;
	private JsonObject jsonObject = null;
	private ICallInfo callInfo = null;
	private String payload = null;

	/**
	 * 
	 * @param requestId
	 * @param queueName
	 * @param weblogicQueueResourceUri
	 * @param callInfo
	 */
	public QueueCall(String requestId,String payload, String queueName,
			String weblogicQueueResourceUri, ICallInfo callInfo) {
		this.requestId = requestId;
		this.payload = payload;
		this.queueName = queueName;
		this.weblogicQueueResourceUri = weblogicQueueResourceUri;
		this.callInfo = callInfo;

	}

	@Override
	public String call() throws Exception {
		callQueueService();
		return "Queue called";
	}
	
	
	

	/**
	 * call queueService to push message to queue
	 */
	private void callQueueService() {
		try {
			PayLoadToXMLPojo payLoadToXMLPojo = fetchPayload();
			jsonObject = new JsonObject();
			jsonObject.addProperty(YSasConstants.PayLoad.toString(),
					messageToBeSentToQueue(payLoadToXMLPojo));
			jsonObject.addProperty(YSasConstants.RequestID.toString(),
					payLoadToXMLPojo.getRequestID());
			jsonObject.addProperty(YSasConstants.customer.toString(),
					payLoadToXMLPojo.getCustomerID());
			jsonObject.addProperty(YSasConstants.queueName.toString(),
					queueName);
			jsonObject.addProperty(YSasConstants.ApplicationID.toString(),
					payLoadToXMLPojo.getApplicationID());
			
			LoggerUtil.logInfoMessages(jsonObject.toString());
			client = Client.create();
			
			webResource = client.resource(weblogicQueueResourceUri);

			clientResponse = webResource.accept(MediaType.APPLICATION_JSON)
					.type(MediaType.APPLICATION_JSON)
					.post(ClientResponse.class, jsonObject.toString());

			LoggerUtil.logInfoMessages("Value of response code : "
					+ clientResponse.getStatus());
			if (clientResponse.getStatus() != 200) {
				LoggerUtil.logInfoMessages("Call to " + queueName + " failed: "
						+ clientResponse.getStatus());
			} else {
				LoggerUtil.logInfoMessages(queueName
						+ " called successfully : "
						+ clientResponse.getStatus());
			}
		} catch (Exception e) {
			LoggerUtil.logErrorMessages("Call to " + queueName + " failed ", e);
		}
	}
	
	/**
	 * this method call class which creates message that gets pushed to the queue
	 * @return
	 * @throws Exception
	 */
	private PayLoadToXMLPojo fetchPayload() throws Exception {
		IRequestType requestType = new RequestTypeImpl();
		return requestType.formPayLoadBasedOnRequestTypeForQueue(callInfo, requestId, payload);
	}

	/**
	 * call class which has XML message
	 * @param payLoadToXMLPojo
	 * @return
	 * @throws Exception
	 */
	private String messageToBeSentToQueue(PayLoadToXMLPojo payLoadToXMLPojo) throws Exception{
		IPayLoadToXMLForQueue payLoadToXML = new PayLoadToXMLForQueue();
		return handleUnnecessaryCharacters(payLoadToXML.writePayLoadIntoXML(payLoadToXMLPojo));
	}

	/**
	 * unnecessary character gets removed here
	 * @param messageToBeDumpedToQueue
	 * @return
	 */
	private String handleUnnecessaryCharacters(String messageToBeDumpedToQueue) {
		if (messageToBeDumpedToQueue.contains("&lt;"))
			messageToBeDumpedToQueue = messageToBeDumpedToQueue.replaceAll(
					"&lt;", "<");
		if (messageToBeDumpedToQueue.contains("&gt;"))
			messageToBeDumpedToQueue = messageToBeDumpedToQueue.replaceAll(
					"&gt;", ">");
		if (messageToBeDumpedToQueue.contains("&#13;"))
			messageToBeDumpedToQueue = messageToBeDumpedToQueue.replaceAll(
					"&#13;", "");
		return messageToBeDumpedToQueue;
	}

	

}
