package com.dlh.zambas.ysas.queue.payload;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.actional.soapstation.plugin.inproc.DOMType;
import com.actional.soapstation.plugin.inproc.ICallInfo;
import com.dlh.zambas.ysas.payload.pojo.PayLoadToXMLPojo;
import com.dlh.zambas.ysas.utils.LoggerUtil;
import com.dlh.zambas.ysas.utils.YSasConstants;

/**
 * Form SOAP payload for queue call
 * 
 * @author singhg
 *
 */
public class FormSOAPPayload {

	private PayLoadToXMLPojo payLoadToXMLPojo = null;

	/**
	 * set PayLoadToXMLPojo
	 * 
	 * @param callInfo
	 * @param requestID
	 * @param payload
	 * @return
	 * @throws Exception
	 */
	public PayLoadToXMLPojo formSOAPPayloadForQueue(ICallInfo callInfo,
			String requestID, String payload) throws Exception {
		try {
			payLoadToXMLPojo = new PayLoadToXMLPojo();
			Document doc = callInfo.getXmlDocument(
					DOMType.MESSAGE_HEADERS_READ_ONLY).getDOM(true);
			payLoadToXMLPojo.setCustomerID(fetchCustomerID(doc));
			payLoadToXMLPojo.setApplicationID(fetchApplicationID(doc));
			payLoadToXMLPojo.setBody(payload);
			payLoadToXMLPojo.setRequestID(requestID);
			payLoadToXMLPojo.setOperationName(callInfo.getOperationName());
			payLoadToXMLPojo.setServiceName(callInfo.getSvcGroupName());
			payLoadToXMLPojo.setType(YSasConstants.SOAP.toString());
			return payLoadToXMLPojo;
		} catch (Exception e) {
			LoggerUtil.logErrorMessages(
					"Exception occured while parsing SOAP message", e);
			throw new Exception("Exception occured while parsing SOAP message", e);
		}
	}

	/**
	 * fetch CustomerID
	 * 
	 * @param doc
	 * @return
	 * @throws Exception
	 */
	private String fetchCustomerID(Document doc) throws Exception {
		try {
			NodeList wssList = doc.getElementsByTagNameNS(
					YSasConstants.headers_namespace.value(),
					YSasConstants.CustomerID.toString());
			if (null != wssList && null != wssList.item(0)) {
				if (wssList.getLength() == 1) {
					Node wssNode = wssList.item(0);
					return wssNode.getTextContent();
				}
			}
		} catch (Exception e) {
			LoggerUtil.logErrorMessages(
					"Exception occured while fetching cutomerID", e);
			throw new Exception("Exception occured while fetching cutomerID", e);
		}
		return null;
	}

	/**
	 * fetch ApplicationID
	 * 
	 * @param doc
	 * @return
	 * @throws Exception
	 */
	private String fetchApplicationID(Document doc) throws Exception {
		try {
			NodeList wssList = doc.getElementsByTagNameNS(
					YSasConstants.headers_namespace.value(),
					YSasConstants.ApplicationID.toString());
			if (null != wssList && null != wssList.item(0)) {
				if (wssList.getLength() == 1) {
					Node wssNode = wssList.item(0);
					return wssNode.getTextContent();
				}
			}
		} catch (Exception e) {
			LoggerUtil.logErrorMessages(
					"Exception occured while fetching applicationID", e);
			throw new Exception(
					"Exception occured while fetching applicationID", e);
		}
		return null;
	}

}
