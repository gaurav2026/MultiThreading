package com.dlh.zambas.ysas.request.type;

import com.actional.soapstation.plugin.inproc.ICallInfo;
import com.dlh.zambas.ysas.payload.pojo.PayLoadToXMLPojo;
import com.dlh.zambas.ysas.queue.payload.FormPayloadImpl;
import com.dlh.zambas.ysas.queue.payload.IFormPayload;
import com.dlh.zambas.ysas.utils.YSasConstants;

/**
 * call REST or SOAP methods based on call type
 * 
 * @author singhg
 *
 */
public class RequestTypeImpl implements IRequestType {

	private IFormPayload formPayload = null;

	/**
	 * if a call contains "AccessPoint" in its operation name then it's REST
	 * call, else , it's a SOAP call
	 */
	@Override
	public PayLoadToXMLPojo formPayLoadBasedOnRequestTypeForQueue(
			ICallInfo callInfo, String requestID, String payload)
			throws Exception {
		formPayload = new FormPayloadImpl();
		/**
		 * call REST method
		 */
		if (callInfo.getAccessPointName().contains(
				YSasConstants.AccessPoint.toString())) {
			return formPayload.formRESTPayloadForQueue(callInfo, requestID,
					payload);
		}
		/**
		 * call SOAP method
		 */
		else {
			return formPayload.formSOAPPayloadForQueue(callInfo, requestID,
					payload);
		}
	}

}
