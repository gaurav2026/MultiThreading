package com.dlh.zambas.ysas.request.type;

import com.actional.soapstation.plugin.inproc.ICallInfo;
import com.dlh.zambas.ysas.payload.pojo.PayLoadToXMLPojo;

public interface IRequestType {

	 PayLoadToXMLPojo formPayLoadBasedOnRequestTypeForQueue(ICallInfo callInfo, String requestID, String payload) throws Exception;
	 
}
