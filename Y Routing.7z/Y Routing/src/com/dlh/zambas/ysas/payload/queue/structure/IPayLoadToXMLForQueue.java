package com.dlh.zambas.ysas.payload.queue.structure;

import com.dlh.zambas.ysas.payload.pojo.PayLoadToXMLPojo;

public interface IPayLoadToXMLForQueue {

	String writePayLoadIntoXML(PayLoadToXMLPojo payLoadToXmlPojo) throws Exception;
}
