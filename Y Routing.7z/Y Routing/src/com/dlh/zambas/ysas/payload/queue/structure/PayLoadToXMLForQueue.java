package com.dlh.zambas.ysas.payload.queue.structure;

import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.dlh.zambas.ysas.payload.pojo.PayLoadToXMLPojo;
import com.dlh.zambas.ysas.utils.YSasConstants;

/**
 * 
 * @author singhg XML structure --- In this form message gets pushed to the
 *         queue
 */
public class PayLoadToXMLForQueue implements IPayLoadToXMLForQueue {

	public String writePayLoadIntoXML(PayLoadToXMLPojo payLoadToXMLPojo)
			throws Exception {

		try {

			DocumentBuilderFactory docFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

			// root elements
			Document doc = docBuilder.newDocument();
			doc.setXmlStandalone(true);
			Element rootElement = doc.createElement(YSasConstants.Message
					.toString());
			rootElement.setAttribute(YSasConstants.Type.toString(),
					payLoadToXMLPojo.getType());
			rootElement.setAttribute(YSasConstants.RequestID.toString(),
					payLoadToXMLPojo.getRequestID());
			rootElement.setAttribute(YSasConstants.ServiceName.toString(),
					payLoadToXMLPojo.getServiceName());
			rootElement.setAttribute(YSasConstants.Operation.toString(),
					payLoadToXMLPojo.getOperationName());
			doc.appendChild(rootElement);

			// REST headers
			if (null != payLoadToXMLPojo.getRestHeaders()) {
				Element restHeaderParams = doc
						.createElement(YSasConstants.RestHeaders.toString());
				restHeaderParams.setTextContent(payLoadToXMLPojo
						.getRestHeaders());
				rootElement.appendChild(restHeaderParams);
			}

			// Path params elements
			if (null != payLoadToXMLPojo.getPathParams()
					&& payLoadToXMLPojo.getPathParams().size() > 0) {
				Element pathParam = doc.createElement(YSasConstants.PathParam
						.toString());
				pathParam.setTextContent(payLoadToXMLPojo.getPathParams()
						.toString());
				rootElement.appendChild(pathParam);
			}

			// Query params elements
			if (null != payLoadToXMLPojo.getQueryParams()
					&& payLoadToXMLPojo.getQueryParams().size() > 0) {
				Element queryParam = doc.createElement(YSasConstants.QueryParam
						.toString());
				queryParam.setTextContent(payLoadToXMLPojo.getQueryParams()
						.toString());
				rootElement.appendChild(queryParam);
			}

			// Body elements
			if (null != payLoadToXMLPojo.getBody()
					&& !payLoadToXMLPojo.getBody().isEmpty()) {
				Element payLoad = doc.createElement(YSasConstants.PayLoad
						.toString());
				payLoad.setTextContent(payLoadToXMLPojo.getBody());
				rootElement.appendChild(payLoad);
			}

			// write the content into a String
			TransformerFactory transformerFactory = TransformerFactory
					.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.METHOD,
					YSasConstants.xml.toString());
			transformer.setOutputProperty(OutputKeys.ENCODING,
					YSasConstants.UTF.value());
			transformer.setOutputProperty(OutputKeys.INDENT,
					YSasConstants.yes.toString());
			StringWriter writer = new StringWriter();
			transformer.transform(new DOMSource(doc), new StreamResult(writer));
			return writer.getBuffer().toString();
		} catch (ParserConfigurationException pce) {
			throw new Exception("Exception occured while parsing : ", pce);
		} catch (TransformerException tfe) {
			throw new Exception(
					"Exception occured while transforming xml to String : ",
					tfe);
		}
	}

}
