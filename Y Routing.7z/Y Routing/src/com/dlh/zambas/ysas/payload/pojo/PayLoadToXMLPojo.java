package com.dlh.zambas.ysas.payload.pojo;

import java.util.List;
import java.util.Map;

/**
 * This Pojo class is for XML structure in which gets dumped to queue through
 * weblogic
 * 
 * @author singhg
 *
 */
public class PayLoadToXMLPojo {
	private String type = null;
	private String requestID = null;
	private String serviceName = null;
	private String operationName = null;
	private String customerID = null;
	private String applicationID = null;
	private Map<String, List<Object>> pathParams = null;
	private Map<String, List<Object>> queryParams = null;
	private String body = null;
	private String restHeaders = null;

	public String getCustomerID() {
		return customerID;
	}

	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	public String getApplicationID() {
		return applicationID;
	}

	public void setApplicationID(String applicationID) {
		this.applicationID = applicationID;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public Map<String, List<Object>> getPathParams() {
		return pathParams;
	}

	public void setPathParams(Map<String, List<Object>> pathParams) {
		this.pathParams = pathParams;
	}

	public Map<String, List<Object>> getQueryParams() {
		return queryParams;
	}

	public void setQueryParams(Map<String, List<Object>> queryParams) {
		this.queryParams = queryParams;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getRestHeaders() {
		return restHeaders;
	}

	public void setRestHeaders(String restHeaders) {
		this.restHeaders = restHeaders;
	}
}
